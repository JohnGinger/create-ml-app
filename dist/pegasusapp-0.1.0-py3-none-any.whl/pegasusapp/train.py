import typer


def run_train():
    typer.echo("Training")
